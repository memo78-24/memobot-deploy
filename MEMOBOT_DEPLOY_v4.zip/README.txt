MEMOBOT DEPLOY PACKAGE v4 - minimal test release
